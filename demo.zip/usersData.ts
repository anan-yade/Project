export interface UserData {
    id: number;
    fname: string;
    lname:string;
    email:string;
    phoneno:number;
    age:number;
    location:string;
  }
  