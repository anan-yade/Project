export interface UserData {
    id: number;
    name: string;
    email:string;
    phoneno:number;
    age:number;
  }
  